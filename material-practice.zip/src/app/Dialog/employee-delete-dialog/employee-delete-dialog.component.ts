import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-delete-dialog',
  templateUrl: './employee-delete-dialog.component.html',
  styleUrls: ['./employee-delete-dialog.component.scss']
})
export class EmployeeDeleteDialogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
