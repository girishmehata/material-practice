export interface EmployeeDetails {
    index: number;
    empName: string;
    position: string;
    bloodGroup: string;
    address: string;
  }